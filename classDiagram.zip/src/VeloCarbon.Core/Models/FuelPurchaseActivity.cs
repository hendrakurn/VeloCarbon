using System;
using VeloCarbon.Core.Enums;

namespace VeloCarbon.Core.Models;

public class FuelPurchaseActivity : ActivityRecord
{
    public Guid VehicleId { get; set; }
    public DateTime PurchaseDate { get; set; }
    public FuelType FuelType { get; set; }
    public decimal LitersPurchased { get; set; }
    public decimal? TotalCost { get; set; }
    public Vehicle? Vehicle { get; set; }
    public FuelPurchaseActivity()
    {
        Unit = ActivityUnit.Liter;
    }

    public override decimal GetActivityValue()
    {
        return LitersPurchased;
    }
}
