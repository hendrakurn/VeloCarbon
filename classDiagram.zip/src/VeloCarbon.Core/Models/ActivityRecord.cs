using System;
using VeloCarbon.Core.Enums;

namespace VeloCarbon.Core.Models;

public abstract class ActivityRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserProfileId { get; set; }
    public ActivityUnit Unit { get; set; }
    public UserProfile? UserProfile { get; set; }
    public EmissionCalculation? EmissionCalculation { get; set; }
    public abstract decimal GetActivityValue();
}
