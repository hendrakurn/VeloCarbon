using System;
using System.Collections.Generic;
using System.Linq;
using VeloCarbon.Core.Enums;

namespace VeloCarbon.Core.Models;

public class ElectricityUsage : ActivityRecord
{
    public ElectricityInputMethod InputMethod { get; set; }
    public decimal UsageKWh { get; set; }
    public DateTime PeriodStart { get; set; }
    public DateTime PeriodEnd { get; set; }
    public ICollection<ApplianceUsage> ApplianceUsages { get; set; } = new List<ApplianceUsage>();
    public ElectricityUsage()
    {
        Unit = ActivityUnit.KilowattHour;
    }
    public override decimal GetActivityValue()
    {
        if (InputMethod == ElectricityInputMethod.ApplianceEstimate && ApplianceUsages.Count > 0)
        {
            return ApplianceUsages.Sum(a => a.EstimateKWh());
        }

        return UsageKWh;
    }
}
